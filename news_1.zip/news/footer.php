<footer class="site-footer">
      <div class="container">
        

        <div class="row">
          
              

          
          
        </div>
        <div class="row pt-5 mt-5 text-center">
          <div class="col-md-12">
            <p>
        
            Copyright &copy; <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>document.write(new Date().getFullYear());</script> IFTI MUNIA cleaning service | CSE471<i class="icon-heart text-warning" aria-hidden="true"></i>

            </p>
          </div>
          
        </div>
      </div>
    </footer>